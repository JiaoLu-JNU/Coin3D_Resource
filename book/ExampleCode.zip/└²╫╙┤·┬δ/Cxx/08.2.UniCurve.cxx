/*
 * Copyright 1991-1995, Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED
 *
 * UNPUBLISHED -- Rights reserved under the copyright laws of the United
 * States.   Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure.
 *
 * U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 * Use, duplication or disclosure by the Government is subject to restrictions
 * as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 * in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 * in similar or successor clauses in the FAR, or the DOD or NASA FAR
 * Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 * 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 *
 * THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 * INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 * DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 * PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 * GRAPHICS, INC.
 */
/*--------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 8, example 2.
 *
 *  This example creates and displays a Uniform B-Spline curve
 *  that passes through the end control points.
 *  The curve is order 4 with 13 control points and a knot
 *  vector of length 17.  The end knots have multiplicity
 *  4 to illustrate the curve passing through the endpoints.
 *--------------------------------------------------------*/
#include "CoinDef.h"
#include <Inventor/SoDB.h>
#include <Inventor/SoInput.h>
#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>
#include <Inventor/nodes/SoBaseColor.h>
#include <Inventor/nodes/SoCamera.h>
#include <Inventor/nodes/SoComplexity.h>
#include <Inventor/nodes/SoCoordinate3.h>
#include <Inventor/nodes/SoDrawStyle.h>
#include <Inventor/nodes/SoLightModel.h>
#include <Inventor/nodes/SoMaterial.h>
#include <Inventor/nodes/SoNurbsCurve.h>
#include <Inventor/nodes/SoRotation.h>
#include <Inventor/nodes/SoScale.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoTranslation.h>

#ifdef WIN32

#endif

// Maximum length of Microsoft string literal is 2048 bytes!!!!
// Break it into 2 pieces.
// Also change path for texture image files to relative path.
static char *
floorData1 = 
"#Inventor V2.0 ascii\n"
"Separator {\n"
"   SpotLight {\n"
"      cutOffAngle 0.9\n"
"      dropOffRate 0.2\n" 
"      location 6 12 2\n" 
"      direction 0 -1 0\n"
"   }\n"
"   ShapeHints {\n"
"      faceType UNKNOWN_FACE_TYPE\n"
"   }\n"
"   Texture2Transform {\n"
"      #rotation 1.57\n"
"      scaleFactor 8 8\n"
"   }\n"
"   Texture2 {\n"
"      filename ../data/oak.gif\n"
"   }\n"
"   NormalBinding {\n"
"        value  PER_PART\n"
"   }\n"
"   Material { diffuseColor 1 1 1 specularColor 1 1 1 shininess 0.4 }\n"
"   DEF FloorPanel Separator {\n"
"      DEF FloorStrip Separator {\n"
"         DEF FloorBoard Separator {\n"
"            Normal { vector 0 1 0 }\n"
"            TextureCoordinate2 {\n"
"               point [ 0 0, 0.5 0, 0.5 2, 0.5 4, 0.5 6,\n"
"                       0.5 8, 0 8, 0 6, 0 4, 0 2 ] }\n"
"            Coordinate3 {\n"
"               point [ 0 0 0, .5 0 0, .5 0 -2, .5 0 -4, .5 0 -6,\n"
"                       .5 0 -8, 0 0 -8, 0 0 -6, 0 0 -4, 0 0 -2, ]\n"
"            }\n";

static char *
floorData2 = 
"            FaceSet { numVertices 10 }\n"
"            BaseColor { rgb 0.3 0.1 0.0 }\n"
"            Translation { translation 0.125 0 -0.333 }\n"
"            Cylinder { parts TOP radius 0.04167 height 0.002 }\n"
"            Translation { translation 0.25 0 0 }\n"
"            Cylinder { parts TOP radius 0.04167 height 0.002 }\n"
"            Translation { translation 0 0 -7.333 }\n"
"            Cylinder { parts TOP radius 0.04167 height 0.002 }\n"
"            Translation { translation -0.25 0 0 }\n"
"            Cylinder { parts TOP radius 0.04167 height 0.002 }\n"
"         }\n"
"         Translation { translation 0 0 8.03 }\n"
"         USE FloorBoard\n"
"         Translation { translation 0 0 8.04 }\n"
"         USE FloorBoard\n"
"      }\n"
"      Translation { translation 0.53 0 -0.87 }\n"
"      USE FloorStrip\n"
"      Translation { translation 0.53 0 -2.3 }\n"
"      USE FloorStrip\n"
"      Translation { translation 0.53 0 1.3 }\n"
"      USE FloorStrip\n"
"      Translation { translation 0.53 0 1.1 }\n"
"      USE FloorStrip\n"
"      Translation { translation 0.53 0 -0.87 }\n"
"      USE FloorStrip\n"
"      Translation { translation 0.53 0 1.7 }\n"
"      USE FloorStrip\n"
"      Translation { translation 0.53 0 -0.5 }\n"
"      USE FloorStrip\n"
"   }\n"
"   Translation { translation 4.24 0 0 }\n"
"   USE FloorPanel\n"
"   Translation { translation 4.24 0 0 }\n"
"   USE FloorPanel\n"
"}";

static char *floorData;

////////////////////////////////////////////////////////////
// CODE FOR The Inventor Mentor STARTS HERE

// The control points for this curve
const float 
pts[13][3] = {
  { 6.0,  0.0,  6.0},
  {-5.5,  0.5,  5.5},
  {-5.0,  1.0, -5.0},
  { 4.5,  1.5, -4.5},
  { 4.0,  2.0,  4.0},
  {-3.5,  2.5,  3.5},
  {-3.0,  3.0, -3.0},
  { 2.5,  3.5, -2.5},
  { 2.0,  4.0,  2.0},
  {-1.5,  4.5,  1.5},
  {-1.0,  5.0, -1.0},
  { 0.5,  5.5, -0.5},
  { 0.0,  6.0,  0.0}
};

// The knot vector
float 
knots[17] = 
{
  0, 0, 0, 0,
  1, 2, 3, 4, 
  5, 6, 7, 8, 
  9, 10, 10, 10, 
  10
};

// Create the nodes needed for the B-Spline curve.
SoSeparator *
makeCurve()
{
  SoSeparator *curveSep = new SoSeparator();
  curveSep->ref();
  
  // Set the draw style of the curve.
  SoDrawStyle *drawStyle  = new SoDrawStyle;
  drawStyle->lineWidth = 4;
  curveSep->addChild(drawStyle);
  
  // Define the NURBS curve including the control points
  // and a complexity.
  SoComplexity  *complexity = new SoComplexity;
  SoCoordinate3 *controlPts = new SoCoordinate3;
  SoNurbsCurve  *curve      = new SoNurbsCurve;
  complexity->value = 0.8f;
  controlPts->point.setValues(0, 13, pts);
  curve->numControlPoints = 13;
  curve->knotVector.setValues(0, 17, knots);
  curveSep->addChild(complexity);
  curveSep->addChild(controlPts);
  curveSep->addChild(curve);
  
  curveSep->unrefNoDelete();
  return curveSep;
}

// CODE FOR The Inventor Mentor ENDS HERE
////////////////////////////////////////////////////////////

int
main(int, char **argv)
{
  floorData = new char[strlen(floorData1)+strlen(floorData2)+1];
  strcpy(floorData,floorData1);
  strcat(floorData,floorData2);
  
  // Initialize Inventor and Win
  HWND appWindow = SoWin::init(argv[0]);
  if (appWindow == NULL)
    exit(1);
  
  SoSeparator *root  = new SoSeparator;
  root->ref();
  
  // Create the scene graph for the spiral
  SoSeparator  *spiral    = new SoSeparator;
  SoSeparator  *curveSep  = makeCurve();
  SoLightModel *lmodel    = new SoLightModel;
  SoBaseColor  *clr       = new SoBaseColor;
  
  lmodel->model = SoLightModel::BASE_COLOR;
  clr->rgb.setValue(SbColor(1.0f, 0.0f, 0.1f));
  spiral->addChild(lmodel);
  spiral->addChild(clr);
  spiral->addChild(curveSep);
  root->addChild(spiral);
  
  // Create the scene graph for the floor
  SoSeparator   *floor = new SoSeparator;
  SoTranslation *xlate = new SoTranslation;
  SoRotation    *rot   = new SoRotation;
  SoScale       *scale = new SoScale;     
  SoInput       in;
  SoNode        *result;
  
  in.setBuffer(floorData, strlen(floorData));
  SoDB::read(&in, result);
  xlate->translation.setValue(SbVec3f(-12.0f, -5.0f, -5.0f));
  scale->scaleFactor.setValue(SbVec3f(2.0f, 1.0f, 2.0f));
  rot->rotation.setValue(SbRotation(SbVec3f(0.0f, 1.0f, 0.0f), (float)(M_PI/2.0f)));
  floor->addChild(rot);
  floor->addChild(xlate);
  floor->addChild(scale);
  floor->addChild(result);
  root->addChild(floor);
  
  // Create the scene graph for the spiral's shadow
  SoSeparator  *shadow = new SoSeparator;
  SoLightModel *shmdl  = new SoLightModel;
  SoMaterial   *shmtl  = new SoMaterial;
  SoBaseColor  *shclr  = new SoBaseColor;
  SoTranslation *shxl  = new SoTranslation;
  SoScale      *shscl  = new SoScale;
  
  shmdl->model = SoLightModel::BASE_COLOR;
  shclr->rgb.setValue(SbColor(0.21f, 0.15f, 0.09f));
  shmtl->transparency = 0.5f;
  shxl->translation.setValue(SbVec3f(0.0f, -4.9f, 0.0f));
  shscl->scaleFactor.setValue(SbVec3f(1.0f, 0.0f, 1.0f));
  shadow->addChild(shmtl);
  shadow->addChild(shmdl);
  shadow->addChild(shclr);
  shadow->addChild(shxl);
  shadow->addChild(shscl);
  shadow->addChild(curveSep);
  root->addChild(shadow);
  
  // Initialize an Examiner Viewer
  SoWinExaminerViewer *viewer =
    new SoWinExaminerViewer(appWindow);
  viewer->setSceneGraph(root);
  viewer->setTitle("B-Spline Curve");
  SoCamera *cam = viewer->getCamera();
  cam->position.setValue(SbVec3f(-6.0, 8.0, 20.0));
  cam->pointAt(SbVec3f(0.0, -2.0, -4.0));
  viewer->show();
  
  SoWin::show(appWindow);
  SoWin::mainLoop();
  
  delete floorData;

  return 0;
}

