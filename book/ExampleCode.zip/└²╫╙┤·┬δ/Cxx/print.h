#ifndef	__MV_PRINT_H__
#define __MV_PRINT_H__

/*
** Copyright 1993, Template Graphics Software, Inc.
** All Rights Reserved.
**
** This is UNPUBLISHED PROPRIETARY SOURCE CODE of 
** Template Graphics Software, Inc.;
** the contents of this file may not be disclosed to third parties, copied or
** duplicated in any form, in whole or in part, without the prior written
** permission of Template Graphics Software, Inc.
**
** RESTRICTED RIGHTS LEGEND:
** Use, duplication or disclosure by the Government is subject to restrictions
** as set forth in subdivision (c)(1)(ii) of the Rights in Technical Data
** and Computer Software clause at DFARS 252.227-7013, and/or in similar or
** successor clauses in the FAR, DOD or NASA FAR Supplement. Unpublished -
** rights reserved under the Copyright Laws of the United States.
**
** $Revision: 1.3 $
** $Date: 2001/07/31 21:00:57 $
*/
#include <stdio.h>
#include <stdlib.h>


#ifndef	TGS_PRINT_NO_RENAMES
#define printf		    __win_printf
#define vprintf		    __win_vprintf
#define fprintf		    __win_fprintf
#define vfprintf	    __win_vfprintf
#define fflush		    __win_fflush
#define exit		    __win_exit
#endif	/* !TGS_PRINT_NO_RENAMES */

#undef	stdin
#undef	stdout
#undef	stderr
#undef	stdprn
#undef 	stdaux
#define	stdin	((FILE *)1)
#define	stdout	((FILE *)2)
#define	stderr	((FILE *)3)
#define	stdprn	((FILE *)4)
#define	stdaux	((FILE *)5)

#ifdef __cplusplus
extern "C" {
#endif

void __win__print_init(int force);
int  __win_printf(const char *fmt, ...);
int  __win_vprintf(const char *fmt, va_list arg);
int  __win_fprintf(FILE *s, const char *fmt, ...);
int  __win_vfprintf(FILE *s, const char *fmt, va_list arg);
int  __win_fflush(FILE *s);
void __win_exit(int rv);
FILE * __AllocConsole(void);
FILE * __GetConsole(void);

#ifdef __cplusplus
}
#endif

#endif	/* !__MV_PRINT_H__ */
