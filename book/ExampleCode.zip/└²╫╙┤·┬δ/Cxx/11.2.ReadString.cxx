/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*--------------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 11, example 2.
 *
 *  Example of creatinge a scene graph by reading from a string.
 *  Create a dodecahedron, made of an IndexedFaceSet.  
 *------------------------------------------------------------*/
#include "CoinDef.h"
#include <string.h>


#include <Inventor/SoDB.h>
#include <Inventor/SoInput.h>
#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>
#include <Inventor/nodes/SoSeparator.h>

#ifdef WIN32

#endif

/////////////////////////////////////////////////////////////
// CODE FOR The Inventor Mentor STARTS HERE

// Reads a dodecahedron from the following string: 
// (Note: ANSI compilers automatically concatenate 
// adjacent string literals together, so the compiler sees 
// this as one big string)

static char *
dodecahedron =
"Separator {"
"   Normal {"
"      vector ["
"         0.553341 0 0.832955, 0.832955 0.553341 0,"
"         0.832955 -0.553341 0, 0 -0.832955 0.553341,"
"         -0.553341 0 0.832955, 0 0.832955 0.553341,"
"         0 0.832955 -0.553341, -0.832955 0.553341 0,"
"         -0.832955 -0.553341 0, 0 -0.832955 -0.553341,"
"         0.553341 0 -0.832955, -0.553341 0 -0.832955,"
"      ]"
"   }"
"   NormalBinding { value PER_FACE }"
"   Material {"
"      diffuseColor ["
"         1  0  0,   0 1  0,   0  0 1,   0  1  1,"
"         1  0  1,  .5 1  0,  .5  0 1,  .5  1  1,"
"         1 .3 .7,  .3 1 .7,  .3 .7 1,  .5 .5 .8"
"      ]"
"   }"
"   MaterialBinding { value PER_FACE }"
"   Coordinate3 {"
"      point ["
"         1.7265 0 0.618,    1 1 1,"
"         0 0.618 1.7265,    0 -0.618 1.7265,"
"         1 -1 1,    -1 -1 1,"
"         -0.618 -1.7265 0,    0.618 -1.7265 0,"
"         1 -1 -1,    1.7265 0 -0.618,"
"         1 1 -1,    0.618 1.7265 0,"
"         -0.618 1.7265 0,    -1 1 1,"
"         -1.7265 0 0.618,    -1.7265 0 -0.618,"
"         -1 -1 -1,    0 -0.618 -1.7265,"
"         0 0.618 -1.7265,    -1 1 -1"
"      ]"
"   }"
"   IndexedFaceSet {"
"      coordIndex ["
"         1, 2, 3, 4, 0, -1,  0, 9, 10, 11, 1, -1,"
"         4, 7, 8, 9, 0, -1,  3, 5, 6, 7, 4, -1,"
"         2, 13, 14, 5, 3, -1,  1, 11, 12, 13, 2, -1,"
"         10, 18, 19, 12, 11, -1,  19, 15, 14, 13, 12, -1,"
"         15, 16, 6, 5, 14, -1,  8, 7, 6, 16, 17, -1,"
"         9, 8, 17, 18, 10, -1,  18, 17, 16, 15, 19, -1,"
"      ]"
"   }"
"}";

// Routine to create a scene graph representing a dodecahedron
SoNode *
makeDodecahedron()
{
  // Read from the string.
  SoInput in;
  in.setBuffer(dodecahedron, strlen(dodecahedron));
  
  SoNode *result;
  SoDB::read(&in, result);
  
  return result;
}

// CODE FOR The Inventor Mentor ENDS HERE
/////////////////////////////////////////////////////////////

int
main(int, char **argv)
{
  // Initialize Inventor and Win
  HWND myWindow = SoWin::init(argv[0]);
  if (myWindow == NULL) exit(1);
  
  SoNode *root = makeDodecahedron();
  root->ref();
  
  SoWinExaminerViewer *myViewer = 
    new SoWinExaminerViewer(myWindow);
  myViewer->setSceneGraph(root);
  myViewer->setTitle("String Reader");
  myViewer->show();
  
  SoWin::show(myWindow);
  SoWin::mainLoop();

  return 0;
}
