/*
 * Copyright 1991-1995, Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED
 *
 * UNPUBLISHED -- Rights reserved under the copyright laws of the United
 * States.   Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure.
 *
 * U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 * Use, duplication or disclosure by the Government is subject to restrictions
 * as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 * in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 * in similar or successor clauses in the FAR, or the DOD or NASA FAR
 * Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 * 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 *
 * THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 * INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 * DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 * PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 * GRAPHICS, INC.
 */
/*------------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 16, example 1.
 * 
 *  This example shows how to use the overlay planes with the
 *  viewer components. By default color 0 is used for the
 *  overlay planes background color (clear color), so we use
 *  color 1 for the object. This example also shows how to
 *  load the overlay color map with the wanted color.
 *----------------------------------------------------------*/

#include "CoinDef.h"
#include <Inventor/SoDB.h>
#include <Inventor/SoInput.h>
#include <Inventor/nodes/SoNode.h>
#include <Inventor/nodes/SoCone.h>
#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>
#ifdef sun
#include <Inventor/nodes/SoColorIndex.h>
#include <Inventor/actions/SoSearchAction.h>
#endif

#ifdef sun

#ifdef __cplusplus
extern "C" {
#endif
extern int glXIsOverlayTGS(void);
#ifdef __cplusplus
}
#endif

# pragma weak           glXIsOverlayTGS
#endif


static char *overlayScene = "\
#Inventor V2.0 ascii\n\
\
Separator { \
   OrthographicCamera { \
      position 0 0 5 \
      nearDistance 1.0 \
      farDistance 10.0 \
      height 10 \
   } \
   LightModel { model BASE_COLOR } \
   ColorIndex { index 1 } \
   Coordinate3 { point [ -1 -1 0, -1 1 0, 1 1 0, 1 -1 0] } \
   FaceSet {} \
} ";

#ifdef WIN32

#  include "print.h"
#endif

int
main(int, char **argv)
{
  // Initialize Inventor and Win
  HWND myWindow = SoWin::init(argv[0]);
  
  // read the scene graph in
  SoInput in;
  SoNode *scene;
  in.setBuffer((void *)overlayScene, (size_t) strlen(overlayScene));
  if (! SoDB::read(&in, scene) || scene == NULL) {
    printf("Couldn't read scene\n");
    exit(1);
  }
  
  // Allocate the viewer, set the overlay scene and
  // load the overlay color map with the wanted color.
  SbColor color(.5, 1, .5);
  SoWinExaminerViewer *myViewer = new SoWinExaminerViewer(myWindow);
  
#ifdef sun
  if (!glXIsOverlayTGS) {
    long value;
    int num;
    // Get overlay colormap size
    int colorMapSize = myViewer->getOverlayColorMapSize();
    
    // Code which gets a handle to the SoColorIndex node
    SoSearchAction searchAction;
    searchAction.setType(SoColorIndex::getClassTypeId());
    searchAction.setInterest(SoSearchAction::FIRST);
    scene->ref();
    searchAction.apply(scene);
    SoPath *path = searchAction.getPath();
    if (path) {
      int zi;
      for (zi=0;zi<path->getLength();zi++) {
        SoNode *child;
        SoType type1;
        
        child = path->getNode(zi);
        type1 = child->getTypeId();
        if (type1 == SoColorIndex::getClassTypeId()) {
          num = ((SoColorIndex *)child)->index.getNum();
          value = ((SoColorIndex *)child)->index[0];
          
          // Modify the index to the high end of the colormap
          ((SoColorIndex *)child)->index.set1Value(0,
            colorMapSize-1-value);
        }
      }
    }
    // Set the overlay colormap with the color we want
    myViewer->setOverlayColorMap(colorMapSize-1-value, 1, &color);
  }
  else {
    myViewer->setOverlayColorMap(1, 1, &color);
  }
#else
  myViewer->setOverlayColorMap(1, 1, &color);
#endif
  
  //myViewer->setSceneGraph(new SoCone);
  myViewer->setOverlaySceneGraph(scene);
  myViewer->setTitle("Overlay Plane");
  
  // Show the viewer and loop forever
  myViewer->show();
  SoWin::show(myWindow);  // Display main window
  SoWin::mainLoop();

  return 0;
}
