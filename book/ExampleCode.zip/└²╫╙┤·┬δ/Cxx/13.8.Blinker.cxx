/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*--------------------------------------------------------------
 *  This is an example from the Inventor Mentor
 *  chapter 13, example 9.
 *
 *  Blinker node.
 *  Use a blinker node to flash a neon ad sign on and off
 *------------------------------------------------------------*/

#include "CoinDef.h"
#include <Inventor/SoDB.h>
#include <Inventor/SoInput.h>
#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/SoWinRenderArea.h>
#include <Inventor/nodes/SoBlinker.h>
#include <Inventor/nodes/SoDirectionalLight.h>
#include <Inventor/nodes/SoMaterial.h>
#include <Inventor/nodes/SoPerspectiveCamera.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoText3.h>

#ifdef WIN32

#endif

int
main(int, char **argv)
{
  // Initialize Inventor and Win
  HWND myWindow = SoWin::init(argv[0]);  
  if (myWindow == NULL) exit(1);     
  
  // Set up camera and light
  SoSeparator *root = new SoSeparator;
  root->ref();
  SoPerspectiveCamera *myCamera = new SoPerspectiveCamera;
  root->addChild(myCamera);
  root->addChild(new SoDirectionalLight);
  
  // Read in the parts of the sign from a file
  SoInput myInput;
  if (!myInput.openFile("../data/eatAtJosies.iv")) 
    exit (1);
  SoSeparator *fileContents = SoDB::readAll(&myInput);
  if (fileContents == NULL) exit (1);
  
  SoSeparator *eatAt;
  eatAt = (SoSeparator *)SoNode::getByName("EatAt");
  SoSeparator *josie;
  josie = (SoSeparator *)SoNode::getByName("Josies");
  SoSeparator *frame;
  frame = (SoSeparator *)SoNode::getByName("Frame");
  
  //////////////////////////////////////////////////////////////
  // CODE FOR The Inventor Mentor STARTS HERE
  
  // Add the non-blinking part of the sign to the root
  root->addChild(eatAt);
  
  // Add the fast-blinking part to a blinker node
  SoBlinker *fastBlinker = new SoBlinker;
  root->addChild(fastBlinker);
  fastBlinker->speed = 2;  // blinks 2 times a second
  fastBlinker->addChild(josie);
  
  // Add the slow-blinking part to another blinker node
  SoBlinker *slowBlinker = new SoBlinker;
  root->addChild(slowBlinker);
  slowBlinker->speed = 0.5;  // 2 secs per cycle; 1 on, 1 off
  slowBlinker->addChild(frame);
  
  // CODE FOR The Inventor Mentor ENDS HERE
  //////////////////////////////////////////////////////////////
  
  // Set up and display render area 
  SoWinRenderArea *myRenderArea = new SoWinRenderArea(myWindow);
  SbViewportRegion myRegion(myRenderArea->getSize()); 
  myCamera->viewAll(root, myRegion);
  
  myRenderArea->setSceneGraph(root);
  myRenderArea->setTitle("Neon");
  myRenderArea->show();
  SoWin::show(myWindow);
  SoWin::mainLoop();

  return 0;
}
