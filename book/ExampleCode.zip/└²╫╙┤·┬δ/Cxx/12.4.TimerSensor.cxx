/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*--------------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 12, example 4.
 *
 *  Timer sensors.  An object is rotated by a timer sensor.
 *  (called "rotatingSensor").  The interval between calls 
 *  controls how often it rotates.
 *  A second timer (called "schedulingSensor") goes off
 *  every 5 seconds and changes the interval of 
 *  "rotatingSensor".  The interval alternates between
 *  once per second and 10 times per second.
 *  This example could also be done using engines.
 *------------------------------------------------------------*/

#include "CoinDef.h"
#include <Inventor/SoDB.h>
#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>
#include <Inventor/nodes/SoCone.h>
#include <Inventor/nodes/SoRotation.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoTransform.h>
#include <Inventor/sensors/SoTimerSensor.h>

#ifdef WIN32

#  include "print.h"
#endif

///////////////////////////////////////////////////////////
// CODE FOR The Inventor Mentor STARTS HERE

// This function is called either 10 times/second or once every
// second; the scheduling changes every 5 seconds (see below):
static void
rotatingSensorCallback(void *data, SoSensor *)
{
  // Rotate an object...
  SoRotation *myRotation = (SoRotation *)data;
  SbRotation currentRotation = myRotation->rotation.getValue();
  currentRotation = 
    SbRotation(SbVec3f(0.0f, 0.0f, 1.0f), 
    (float)(M_PI/90.0f)) * currentRotation;
  myRotation->rotation.setValue(currentRotation);
}

// This function is called once every 5 seconds, and
// reschedules the other sensor.
static void
schedulingSensorCallback(void *data, SoSensor *)
{
  SoTimerSensor *rotatingSensor = (SoTimerSensor *)data;
  rotatingSensor->unschedule();
  if (rotatingSensor->getInterval() == 1.0f)
    rotatingSensor->setInterval(1.0f/10.0f);
  else rotatingSensor->setInterval(1.0f);
  rotatingSensor->schedule();
}

// CODE FOR The Inventor Mentor ENDS HERE
///////////////////////////////////////////////////////////

int
main(int argc, char **argv)
{
  if (argc != 2) {
    fprintf(stderr, "Usage: %s filename.iv\n", argv[0]);
    exit(1);
  }
  
  HWND myWindow = SoWin::init(argv[0]);
  if (myWindow == NULL) exit(1);
  
  SoSeparator *root = new SoSeparator;
  root->ref();
  
  ///////////////////////////////////////////////////////////
  // CODE FOR The Inventor Mentor STARTS HERE
  
  SoRotation *myRotation = new SoRotation;
  root->addChild(myRotation);
  
  SoTimerSensor *rotatingSensor =
    new SoTimerSensor(rotatingSensorCallback, myRotation);
  rotatingSensor->setInterval(1.0f); // scheduled once per second
  rotatingSensor->schedule();
  
  SoTimerSensor *schedulingSensor =
    new SoTimerSensor(schedulingSensorCallback, rotatingSensor);
  schedulingSensor->setInterval(5.0f); // once per 5 seconds
  schedulingSensor->schedule();
  
  // CODE FOR The Inventor Mentor ENDS HERE
  ///////////////////////////////////////////////////////////
  
  SoInput inputFile;
  if (inputFile.openFile(argv[1]) == FALSE) {
    fprintf(stderr, "Could not open file %s\n", argv[1]);
    exit(1);
  }
  root->addChild(SoDB::readAll(&inputFile));
  
  SoWinExaminerViewer *myViewer =
    new SoWinExaminerViewer(myWindow);
  myViewer->setSceneGraph(root);
  myViewer->setTitle("Two Timers");
  myViewer->show();
  
  SoWin::show(myWindow);  // Display main window
  SoWin::mainLoop();        // Main Inventor event loop

  return 0;
}
