/*
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*-----------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 9, example 1.
 *
 *  Printing example.
 *  Read in an Inventor file and display it in ExaminerViewer.  Press
 *  the "p" key and the scene renders into a PostScript
 *  file for printing.
 *----------------------------------------------------------*/
#include "CoinDef.h"

#include <Inventor/SbViewportRegion.h>
#include <Inventor/SoDB.h>
#include <Inventor/SoOffscreenRenderer.h>
#include <Inventor/events/SoKeyboardEvent.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoEventCallback.h>
#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>

#ifdef WIN32

#  include "print.h"	//Enable printf/fprintf for messages
#endif

typedef struct cbdata {
  SoWinExaminerViewer *vwr;
  char *filename;
  SoNode *scene;
} callbackData;

//////////////////////////////////////////////////////////////
// CODE FOR The Inventor Mentor STARTS HERE

SbBool 
printToPostScript(SoNode *root, FILE *file,
                  SoWinExaminerViewer *viewer, int printerDPI)
{
  // Calculate size of the images in inches which is equal to
  // the size of the viewport in pixels divided by the number
  // of pixels per inch of the screen device.  This size in
  // inches will be the size of the Postscript image that will
  // be generated.
  const SbViewportRegion &vp  = viewer->getViewportRegion();
  const SbVec2s &imagePixSize = vp.getViewportSizePixels();
  SbVec2f imageInches;
  float pixPerInch;
  
  pixPerInch = SoOffscreenRenderer::getScreenPixelsPerInch();
  imageInches.setValue((float)imagePixSize[0] / pixPerInch,
    (float)imagePixSize[1] / pixPerInch);
  
  // The resolution to render the scene for the printer
  // is equal to the size of the image in inches times
  // the printer DPI;
  SbVec2s postScriptRes;
  postScriptRes.setValue((short)(imageInches[0]*printerDPI),
    (short)(imageInches[1]*printerDPI));
  
  // Create a viewport to render the scene into.
  SbViewportRegion myViewport;
  myViewport.setWindowSize(postScriptRes);
  myViewport.setPixelsPerInch((float)printerDPI);
  
  // Render the scene
  SoOffscreenRenderer *myRenderer = 
    new SoOffscreenRenderer(myViewport);
#ifdef WIN32
  // White background uses up a lot less ink...
  myRenderer->setBackgroundColor(SbColor(1.0f, 1.0f, 1.0f));
#endif
  if (!myRenderer->render(root)) {
    delete myRenderer;
    return FALSE;
  }
  
  // Generate PostScript and write it to the given file
//#ifdef WIN32
//  myRenderer->writeToBMP(file);
//#else
  myRenderer->writeToPostScript(file);
//#endif
  
  delete myRenderer;
  return TRUE;
}

// CODE FOR The Inventor Mentor ENDS HERE
//////////////////////////////////////////////////////////////

static void
processKeyEvents( void *data, SoEventCallback *cb )
{
  if (SO_KEY_PRESS_EVENT(cb->getEvent(), P)) {
    
    callbackData *cbData = (callbackData *)data;
    FILE *myFile = fopen(cbData->filename, "wb");
    
    if (myFile == NULL) {
      fprintf(stderr, "Cannot open output file\n");
      exit(1);
    }
    
    printf("Printing scene... ");
    fflush(stdout);
    if (!printToPostScript(cbData->scene, myFile,
      cbData->vwr, 75)) {
      fprintf(stderr, "Cannot print image\n");
      fclose(myFile);
      exit(1);
    }
    
    fclose(myFile);
    printf("  ...done printing.\n");
    fflush(stdout);
    cb->setHandled(); 
  } 
}

int
main(int argc, char **argv)
{
  // Initialize Inventor and Win
  HWND appWindow = SoWin::init(argv[0]);
  if (appWindow == NULL)
    exit(1);
  
  // Verify the command line arguments
  if (argc != 3) {
#ifdef WIN32
    fprintf(stderr, "Usage: %s infile.iv outfile.bmp\n", argv[0]);
#else
    fprintf(stderr, "Usage: %s infile.iv outfile.ps\n", argv[0]);
#endif
    exit(1); 
  }
  
  printf("To print the scene: press the 'p' key while in picking mode\n");
  
  // Make a scene containing an event callback node
  SoSeparator         *root    = new SoSeparator;
  SoEventCallback     *eventCB = new SoEventCallback;
  root->ref();
  root->addChild(eventCB);
  
  // Read the geometry from a file and add to the scene
  SoInput myInput;
  if (!myInput.openFile(argv[1]))
    exit (1);
  SoSeparator *geomObject = SoDB::readAll(&myInput);
  if (geomObject == NULL)
    exit (1);
  root->addChild(geomObject);
  
  SoWinExaminerViewer *viewer =
    new SoWinExaminerViewer(appWindow, NULL, TRUE, 
    SoWinExaminerViewer::BUILD_ALL, SoWinExaminerViewer::EDITOR);
  viewer->setSceneGraph(root);
#ifdef WIN32
  viewer->setTitle("Print to Bitmap");
#else
  viewer->setTitle("Print to PostScript");
#endif
  
  // Setup the event callback data and routine for performing the print
  callbackData *data = new callbackData;
  data->vwr = viewer;
  data->filename = argv[2];
  data->scene = viewer->getSceneGraph();
  eventCB->addEventCallback(SoKeyboardEvent::getClassTypeId(),
    processKeyEvents, data);
  viewer->show();
  
  SoWin::show(appWindow);
  SoWin::mainLoop();

  return 0;
}
