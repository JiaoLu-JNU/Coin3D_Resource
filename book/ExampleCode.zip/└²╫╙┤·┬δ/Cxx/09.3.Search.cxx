/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*------------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 9, example 3.
 *
 *  Search Action example.
 *  Read in a scene from a file.
 *  Search through the scene looking for a light.
 *  If none exists, add a directional light to the scene
 *  and print out the modified scene.
 *-----------------------------------------------------------*/

#include "CoinDef.h"
#include <Inventor/SoDB.h>
#include <Inventor/actions/SoSearchAction.h>
#include <Inventor/actions/SoWriteAction.h>
#include <Inventor/nodes/SoDirectionalLight.h>
#include <Inventor/nodes/SoSeparator.h>

#ifdef WIN32

#  include "print.h"
#endif

int
main(int, char **)
{
#ifdef WIN32
  SoOutput conOut;
  conOut.setFilePointer(__AllocConsole());
#endif
  
  // Initialize Inventor
  SoDB::init();
  
  // Open and read input scene graph
  SoInput sceneInput;
  if (! sceneInput.openFile("../data/bird.iv"))
    return 1;
  
  SoSeparator *root = SoDB::readAll(&sceneInput);
  if (root == NULL) 
    return 1;
  root->ref();
  
  //////////////////////////////////////////////////////////////
  // CODE FOR The Inventor Mentor STARTS HERE
  
  SoSearchAction mySearchAction;
  
  // Look for first existing light derived from class SoLight
  mySearchAction.setType(SoLight::getClassTypeId());
  mySearchAction.setInterest(SoSearchAction::FIRST);
  
  mySearchAction.apply(root);
  if (mySearchAction.getPath() == NULL) { // No lights found
    // Add a default directional light to the scene
    SoDirectionalLight *myLight = new SoDirectionalLight;
    root->insertChild(myLight, 0);
  }
  
  // CODE FOR The Inventor Mentor ENDS HERE
  //////////////////////////////////////////////////////////////
  
#ifdef WIN32
  SoWriteAction myWriteAction(&conOut);
#else
  SoWriteAction myWriteAction;
#endif
  
  myWriteAction.apply(root);
  
//#ifdef WIN32
//  conOut.flushFile();
//#endif
  
  root->unref();
  
  // The usual exit(0) has been replaced with exit(1) to enable the console
  // window showing the output to stay on the screen until the user deletes it
  exit(1);
  return 0;

}

