/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*--------------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 12, example 1.
 *
 *  Sense changes to a viewer's camera's position.
 *------------------------------------------------------------*/
#include "CoinDef.h"

#include <Inventor/SoDB.h>
#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>
#include <Inventor/nodes/SoCamera.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/sensors/SoFieldSensor.h>

#ifdef WIN32

#  include "print.h"
#endif

// Callback that reports whenever the viewer's position changes.
static void
cameraChangedCB(void *data, SoSensor *)
{
  SoCamera *viewerCamera = (SoCamera *)data;
  
  SbVec3f cameraPosition = viewerCamera->position.getValue();
  printf("Camera position: (%g,%g,%g)\n",
    cameraPosition[0], cameraPosition[1],
    cameraPosition[2]); 
}

int
main(int argc, char **argv)
{
  if (argc != 2) {
    fprintf(stderr, "Usage: %s filename.iv\n", argv[0]);
    exit(1);
  }
  
  HWND myWindow = SoWin::init(argv[0]);
  if (myWindow == NULL) exit(1);
  
  SoInput inputFile;
  if (inputFile.openFile(argv[1]) == FALSE) {
    fprintf(stderr, "Could not open file %s\n", argv[1]);
    exit(1);
  }
  
  SoSeparator *root = SoDB::readAll(&inputFile);
  root->ref();
  
  SoWinExaminerViewer *myViewer =
    new SoWinExaminerViewer(myWindow);
  myViewer->setSceneGraph(root);
  myViewer->setTitle("Camera Sensor");
  myViewer->show();
  
  // Get the camera from the viewer, and attach a 
  // field sensor to its position field:
  SoCamera *camera = myViewer->getCamera();
  SoFieldSensor *mySensor = 
    new SoFieldSensor(cameraChangedCB, camera);
  mySensor->attach(&camera->position);
  
  SoWin::show(myWindow);
  SoWin::mainLoop();

  return 0;
}
