/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*--------------------------------------------------------------
 *  This is an example from the Inventor Mentor
 *  chapter 13, example 3.
 *
 *  Elapsed time engine.
 *  The output from an elapsed time engine is used to control
 *  the translation of the object.  The resulting effect is
 *  that the figure slides across the scene.
 *------------------------------------------------------------*/

#include "CoinDef.h"
#include <Inventor/SoDB.h>
#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/SoWinRenderArea.h>
#include <Inventor/engines/SoCompose.h>
#include <Inventor/engines/SoElapsedTime.h>
#include <Inventor/nodes/SoDirectionalLight.h>
#include <Inventor/nodes/SoMaterial.h>
#include <Inventor/nodes/SoPerspectiveCamera.h>
#include <Inventor/nodes/SoRotationXYZ.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoTransform.h>
#include <Inventor/nodes/SoTranslation.h>

#ifdef WIN32

#endif

int
main(int, char **argv)
{
  // Initialize Inventor and Win
  HWND myWindow = SoWin::init(argv[0]);  
  if (myWindow == NULL) exit(1);     
  
  SoSeparator *root = new SoSeparator;
  root->ref();
  
  // Add a camera and light
  SoPerspectiveCamera *myCamera = new SoPerspectiveCamera;
  myCamera->position.setValue(-2.0f, -2.0f, 5.0f);
  myCamera->heightAngle = (float)(M_PI/2.5f); 
  myCamera->nearDistance = 2.0f;
  myCamera->farDistance = 7.0f;
  root->addChild(myCamera);
  root->addChild(new SoDirectionalLight);
  
  // Set up transformations
  SoTranslation *slideTranslation = new SoTranslation;
  root->addChild(slideTranslation);
  SoTransform *initialTransform = new SoTransform;
  initialTransform->translation.setValue(-5.0f, 0.0f, 0.0f);
  initialTransform->scaleFactor.setValue(10.0f, 10.0f, 10.0f);
  initialTransform->rotation.setValue(SbVec3f(1.0f, 0.0f, 0.0f), 
    (float)(M_PI/2.0f));
  root->addChild(initialTransform);
  
  // Read the figure object from a file and add to the scene
  SoInput myInput;
  if (!myInput.openFile("../data/jumpyMan.iv")) 
    exit (1);
  SoSeparator *figureObject = SoDB::readAll(&myInput);
  if (figureObject == NULL) exit (1);
  root->addChild(figureObject);
  
  // Make the X translation value change over time.
  SoElapsedTime *myCounter = new SoElapsedTime;
  SoComposeVec3f *slideDistance = new SoComposeVec3f;
  slideDistance->x.connectFrom(&myCounter->timeOut);
  slideTranslation->translation.connectFrom(
    &slideDistance->vector);
  
  SoWinRenderArea *myRenderArea = new SoWinRenderArea(myWindow);
  SbViewportRegion myRegion(myRenderArea->getSize()); 
  myRenderArea->setSceneGraph(root);
  myRenderArea->setTitle("Sliding Man");
  myRenderArea->show();
  
  SoWin::show(myWindow);
  SoWin::mainLoop();

  return 0;
}
