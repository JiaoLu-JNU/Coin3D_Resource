/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*------------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 16, example 2.
 * 
 *  This example builds a render area in a window supplied by
 *  the application and a Material Editor in its own window.
 *  It uses callbacks for the component to report new values.
 *----------------------------------------------------------*/

#include "CoinDef.h"
#include <Inventor/SoDB.h> 
#include <Inventor/Win/SoWin.h> 
#include <Inventor/Win/SoWinMaterialEditor.h>
#include <Inventor/Win/SoWinRenderArea.h> 
#include <Inventor/nodes/SoDirectionalLight.h> 
#include <Inventor/nodes/SoMaterial.h> 
#include <Inventor/nodes/SoPerspectiveCamera.h> 
#include <Inventor/nodes/SoSeparator.h> 

#ifdef WIN32

#endif

//  This is called by the Material Editor when a value changes
void
myMaterialEditorCB(void *userData, const SoMaterial *newMtl)
{
  SoMaterial *myMtl = (SoMaterial *) userData;
  
  // Copy all the fields from the new material
  myMtl->copyFieldValues(newMtl);
  
}

int
main(int, char **argv)
{
  // Initialize Inventor and Win
  HWND myWindow = SoWin::init(argv[0]);
  
  // Build the render area in the applications main window
  SoWinRenderArea *myRenderArea = new SoWinRenderArea(myWindow);
  myRenderArea->setSize(SbVec2s(200, 200));
  
  // Build the Material Editor in its own window
  SoWinMaterialEditor *myEditor = new SoWinMaterialEditor;
  
  // Create a scene graph
  SoSeparator *root = new SoSeparator;
  SoPerspectiveCamera *myCamera = new SoPerspectiveCamera;
  SoMaterial *myMaterial = new SoMaterial;
  
  root->ref();
  myCamera->position.setValue(0.212482f, -0.881014f, 2.5f);
  myCamera->heightAngle = (float)(M_PI/4.0f); 
  root->addChild(myCamera);
  root->addChild(new SoDirectionalLight);
  root->addChild(myMaterial);
  
  // Read the geometry from a file and add to the scene
  SoInput myInput;
  if (!myInput.openFile("../data/dogDish.iv")) 
    exit(1);
  SoSeparator *geomObject = SoDB::readAll(&myInput);
  if (geomObject == NULL) 
    exit(1);
  root->addChild(geomObject);
  
  // Add a callback for when the material changes
  myEditor->addMaterialChangedCallback(myMaterialEditorCB, myMaterial); 
  
  // Set the scene graph
  myRenderArea->setSceneGraph(root);
  
  // Show the main window and the Material Editor
  myRenderArea->setTitle("Editor Callback");
  myRenderArea->show();
  SoWin::show(myWindow);
  myEditor->show();
  
  // Loop forever
  SoWin::mainLoop();

  return 0;
}
