/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*--------------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 12, example 3.
 *
 *  Alarm sensor that raises a flag after 10 minutes
 *------------------------------------------------------------*/
#include "CoinDef.h"
#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>
#include <Inventor/nodes/SoCone.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoTransform.h>
#include <Inventor/sensors/SoAlarmSensor.h>

#ifdef WIN32

#endif

///////////////////////////////////////////////////////////
// CODE FOR The Inventor Mentor STARTS HERE

static void
raiseFlagCallback(void *data, SoSensor *)
{
  // We know data is really a SoTransform node:
  SoTransform *flagAngleXform = (SoTransform *)data;
  
  // Rotate flag by 90 degrees about the Z axis:
  flagAngleXform->rotation.setValue(SbVec3f(0.0f, 0.0f, 1.0f), 
    (float)(M_PI/2.0f));
}

// CODE FOR The Inventor Mentor ENDS HERE
///////////////////////////////////////////////////////////

int
main(int, char **argv)
{
  HWND myWindow = SoWin::init(argv[0]); // pass the app name
  if (myWindow == NULL)
    exit(1);
  
  ///////////////////////////////////////////////////////////
  // CODE FOR The Inventor Mentor STARTS HERE
  
  SoTransform *flagXform = new SoTransform;
  
  // Create an alarm that will call the flag-raising callback:
  SoAlarmSensor *myAlarm =
    new SoAlarmSensor(raiseFlagCallback, flagXform);
  myAlarm->setTimeFromNow(5.0f);
  myAlarm->schedule();
  
  // CODE FOR The Inventor Mentor ENDS HERE
  ///////////////////////////////////////////////////////////
  
  SoSeparator *root = new SoSeparator;
  root->ref();
  root->addChild(flagXform);
  SoCone *myCone = new SoCone;
  myCone->bottomRadius = 0.1f;
  root->addChild(myCone);
  
  SoWinExaminerViewer *myViewer = new SoWinExaminerViewer(myWindow);
  
  // Put our scene in myViewer, change the title
  myViewer->setSceneGraph(root);
  myViewer->setTitle("Raise The Cone");
  myViewer->show();
  
  SoWin::show(myWindow);  // Display main window
  SoWin::mainLoop();      // Main Inventor event loop

  return 0;
}

