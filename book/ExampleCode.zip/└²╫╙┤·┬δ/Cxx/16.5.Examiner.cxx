/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*------------------------------------------------------------
 *  This is an example from the Inventor Mentor
 *  chapter 16, example 5.
 *
 *  This example creates a simple scene graph and attaches a
 *  browser Examiner viewer to view the data. The camera and
 *  light in the scene are automatically created by the viewer.
 *-----------------------------------------------------------*/

#include "CoinDef.h"
#include <Inventor/SoDB.h>         
#include <Inventor/Win/SoWin.h>         
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>  
#include <Inventor/nodes/SoSeparator.h>

#ifdef WIN32

#endif

int
main(int, char **argv)
{
  // Initialize Inventor and Win
  HWND myWindow = SoWin::init(argv[0]);
  
  // Build the viewer in the applications main window
  SoWinExaminerViewer *myViewer = 
    new SoWinExaminerViewer(myWindow);
  
  // Read the geometry from a file and add to the scene
  SoInput myInput;
  if (!myInput.openFile("../data/dogDish.iv"))
    exit (1);
  SoSeparator *geomObject = SoDB::readAll(&myInput);
  if (geomObject == NULL)
    exit (1);
  
  // Attach the viewer to the scene graph
  myViewer->setSceneGraph(geomObject);
  
  // Show the main window
  myViewer->show();
  SoWin::show(myWindow);
  
  // Loop forever
  SoWin::mainLoop();
  
  return 0;
}
