/*
 * Copyright 1991-1995, Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED
 *
 * UNPUBLISHED -- Rights reserved under the copyright laws of the United
 * States.   Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure.
 *
 * U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 * Use, duplication or disclosure by the Government is subject to restrictions
 * as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 * in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 * in similar or successor clauses in the FAR, or the DOD or NASA FAR
 * Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 * 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 *
 * THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 * INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 * DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 * PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 * GRAPHICS, INC.
 */
/*-----------------------------------------------------------
 *  This is an example from The Inventor Mentor,
 *  chapter 17, example 3.
 * 
 * This example draws the same scene as Example 17.2, 
 *  but using a GLX window.
 *---------------------------------------------------------*/
#include "CoinDef.h"
#ifdef WIN32
#  include <windows.h>
#  include <Inventor/Win/SoWin.h>

#else
#  include <GL/glx.h>
#  include <unistd.h>
#endif

#include <GL/gl.h>
#include <GL/glu.h>
#include <stdio.h>

#include <Inventor/SoDB.h>
#include <Inventor/actions/SoGLRenderAction.h>
#include <Inventor/nodes/SoCube.h>
#include <Inventor/nodes/SoDirectionalLight.h>
#include <Inventor/nodes/SoLightModel.h>
#include <Inventor/nodes/SoMaterial.h>
#include <Inventor/nodes/SoTransform.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoSphere.h>
#include <Inventor/elements/SoGLLazyElement.h>

#define WINWIDTH 400
#define WINHEIGHT 400

float floorObj[81][3];

// Build an Inventor scene with two objects and some light
void
buildScene(SoGroup *root)
{
  // Some light
  root->addChild(new SoLightModel);
  root->addChild(new SoDirectionalLight);

  // A red cube translated to the left and down
  SoTransform *myTrans = new SoTransform;
  myTrans->translation.setValue(-2.0f, -2.0f, 0.0f);
  root->addChild(myTrans);

  SoMaterial *myMtl = new SoMaterial;
  myMtl->diffuseColor.setValue(1.0f, 0.0f, 0.0f);
  root->addChild(myMtl);

  root->addChild(new SoCube);

  // A blue sphere translated right
  myTrans = new SoTransform;
  myTrans->translation.setValue(4.0f, 0.0f, 0.0f);
  root->addChild(myTrans);

  myMtl = new SoMaterial;
  myMtl->diffuseColor.setValue(0.0f, 0.0f, 1.0f);
  root->addChild(myMtl);

  root->addChild(new SoSphere);
}

// Build a floor that will be rendered using OpenGL.
void
buildFloor()
{
  int a = 0;

  for (float i = -5.0f; i <= 5.0f; i += 1.25f) {
    for (float j = -5.0f; j <= 5.0f; j += 1.25f, a++) {
      floorObj[a][0] = j;
      floorObj[a][1] = 0.0f;
      floorObj[a][2] = i;
    }
  }
}

#ifdef WIN32
// Create and initialize OpenGL window.
void
openWindow(HWND &window)
{
  int pixelformat;
  HGLRC ctx;
  HDC hdc;
  WNDCLASS wndclass;
  PIXELFORMATDESCRIPTOR pfd;
   
  wndclass.style = CS_HREDRAW | CS_VREDRAW;
  wndclass.lpfnWndProc   = ::DefWindowProc;
  wndclass.cbClsExtra    = 0;
  wndclass.cbWndExtra    = 0;
  wndclass.hInstance     = NULL;//SoWin::getInstance();
  wndclass.hIcon         = NULL;
  wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
  wndclass.hbrBackground = NULL;
  wndclass.lpszMenuName  = NULL;
  wndclass.lpszClassName = "17_3GLFloor";
    
  if (! RegisterClass(&wndclass)) {
    SoWin::createSimpleErrorDialog(NULL, "Error",
                                   "RegisterClass failed", NULL);
    exit(1);
  }

  window = CreateWindow("17_3GLFloor",
                        "17_3GLFloor",
                        WS_OVERLAPPEDWINDOW |
                        WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
                        100, 100,               // X Y position
                        WINWIDTH, WINHEIGHT,    // Width Height
                        NULL,                   // Parent
                        NULL,                   // Menu
                        NULL,//SoWin::getInstance(),   // App instance handle
                        NULL);                  // Window creation data
  if (! window) {
    SoWin::createSimpleErrorDialog(NULL, "Error",
                                   "CreateWindow failed", NULL);
    exit(2);
  }

  pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
  pfd.nVersion = 1;
  pfd.dwFlags = PFD_DRAW_TO_WINDOW
    | PFD_SUPPORT_OPENGL
    | PFD_DOUBLEBUFFER;
  pfd.iPixelType = PFD_TYPE_RGBA;
  pfd.cColorBits = 24;
  pfd.cRedBits = 0;
  pfd.cRedShift = 0;
  pfd.cGreenBits = 0;
  pfd.cGreenShift = 0;
  pfd.cBlueBits = 0;
  pfd.cBlueShift = 0;
  pfd.cAlphaBits = 0;
  pfd.cAlphaShift = 0;
  pfd.cAccumBits = 0;
  pfd.cAccumRedBits = 0;
  pfd.cAccumGreenBits = 0;
  pfd.cAccumBlueBits = 0;
  pfd.cAccumAlphaBits = 0;
  pfd.cDepthBits = 32;
  pfd.cStencilBits = 0;
  pfd.cAuxBuffers = 0;
  pfd.iLayerType = PFD_MAIN_PLANE;
  pfd.bReserved = 0;
  pfd.dwLayerMask = 0;
  pfd.dwVisibleMask = 0;
  pfd.dwDamageMask = 0;

  // Setup pixel format
  hdc = GetDC(window);
  if ((pixelformat = ChoosePixelFormat(hdc, &pfd)) == 0) {
    SoWin::createSimpleErrorDialog(NULL, "Error",
                                   "ChoosePixelFormat failed", NULL);
    exit(3);
  }
  if (SetPixelFormat(hdc, pixelformat, &pfd) == FALSE) {
    SoWin::createSimpleErrorDialog(NULL, "Error",
                                   "SetPixelFormat failed", NULL);
    exit(4);
  }
  if ((ctx = wglCreateContext(hdc)) == NULL) {
    SoWin::createSimpleErrorDialog(NULL, "Error",
                                   "wglCreateContext failed", NULL);
    exit(5);
  }
  if (!wglMakeCurrent(hdc, ctx)) {
    SoWin::createSimpleErrorDialog(NULL, "Error",
                                   "wglMakeCurrent failed", NULL);
    exit(6);
  }
  ShowWindow(window, SW_SHOW);

  return;
}
#else
// Callback used by GLX window
static Bool
waitForNotify(Display *, XEvent *e, char *arg)
{
  return (e->type == MapNotify) && 
    (e->xmap.window == (Window)arg);
}

// Create and initialize OpenGL window.
void
openWindow(Display *&display, Window &window)
{
  XVisualInfo *vi;
  Colormap cmap;
  XSetWindowAttributes swa;
  GLXContext cx;
  XEvent event;
  static int attributeList[] = {
    GLX_RGBA,
    GLX_RED_SIZE, 1,
    GLX_GREEN_SIZE, 1,
    GLX_BLUE_SIZE, 1,
    GLX_DEPTH_SIZE, 1,
    GLX_DOUBLEBUFFER,        
    None,
  };

  // Open the X display 
  display = XOpenDisplay(0);

  // Initialize the GLX visual and context
  vi = glXChooseVisual(display, 
                       DefaultScreen(display), attributeList);
  cx = glXCreateContext(display, vi, 0, GL_TRUE);

  // Create the X color map
  cmap = XCreateColormap(display, 
                         RootWindow(display, vi->screen), 
                         vi->visual, AllocNone);

  // Create and map the X window
  swa.colormap = cmap;
  swa.border_pixel = 0;
  swa.event_mask = StructureNotifyMask;
  window = XCreateWindow(display, 
                         RootWindow(display, vi->screen), 100, 100, WINWIDTH,
                         WINHEIGHT, 0, vi->depth, InputOutput, vi->visual, 
                         (CWBorderPixel | CWColormap | CWEventMask), &swa);
  XMapWindow(display, window);
  XIfEvent(display, &event, waitForNotify, (char *)window);

  // Attach the GLX context to the window
  glXMakeCurrent(display, window, cx);
}
#endif

// Draw the lines that make up the floor, using OpenGL
void
drawFloor()
{
  int i;

  glBegin(GL_LINES);
  for (i=0; i<4; i++) {
    glVertex3fv(floorObj[i*18]);
    glVertex3fv(floorObj[(i*18)+8]);
    glVertex3fv(floorObj[(i*18)+17]);
    glVertex3fv(floorObj[(i*18)+9]);
  }

  glVertex3fv(floorObj[i*18]);
  glVertex3fv(floorObj[(i*18)+8]);
  glEnd();

  glBegin(GL_LINES);
  for (i=0; i<4; i++) {
    glVertex3fv(floorObj[i*2]);
    glVertex3fv(floorObj[(i*2)+72]);
    glVertex3fv(floorObj[(i*2)+73]);
    glVertex3fv(floorObj[(i*2)+1]);
  }
  glVertex3fv(floorObj[i*2]);
  glVertex3fv(floorObj[(i*2)+72]);
  glEnd();
}

int
main(int, char **)
{
  // Initialize Inventor
  SoDB::init();

  // Build a simple scene graph
  SoSeparator *root = new SoSeparator;
  root->ref();
  buildScene(root);

  // Build the floor geometry
  buildFloor();

  // Create and initialize window
#ifdef WIN32
  HWND window;
  openWindow(window);
#else
  Display *display;
  Window window;
  openWindow(display, window);
#endif

  glEnable(GL_DEPTH_TEST);
  glClearColor(0.8f, 0.8f, 0.8f, 1.0f);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  // Set up the camera using OpenGL.
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(90.0f, 1.0f, 2.0f, 12.0f);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glTranslatef(0.0f, 0.0f, -5.0f);

  // Render the floor using OpenGL
  glPushMatrix();
  glTranslatef(0.0f, -3.0f, 0.0f);
  glColor3f(0.7f, 0.0f, 0.0f);
  glLineWidth(2.0f);
  glDisable(GL_LIGHTING);
  drawFloor();
  glEnable(GL_LIGHTING);
  glPopMatrix();

  // Render the scene
  SbViewportRegion myViewport(WINWIDTH, WINHEIGHT);
  SoGLRenderAction myRenderAction(myViewport);
 
  myRenderAction.apply(root);

#ifdef WIN32
  SwapBuffers(GetDC(window));
#else
  glXSwapBuffers(display, window); 
#endif
   
  //With inventor 2.1, it's necessary to reset the lazy element
  //any time GL calls are made outside of inventor.  In this example,
  //between the first and second rendering, the inventor state must
  //have both diffuse color and light model reset, since these are
  //modified by the GLX rendering code.  For more information about
  //the lazy element, see the publication,
  //  "Open Inventor 2.1 Porting and Performance Tips"
  
  //To reset the lazy element, first we obtain the state
  //from the action, then obtain the lazy element from the state, 
  //and finally apply a reset to that lazy element.
  
  SoState* state = myRenderAction.getState();
  SoGLLazyElement* lazyElt = 
    (SoGLLazyElement*)SoLazyElement::getInstance(state);
  lazyElt->reset(state, 
                 (SoLazyElement::DIFFUSE_MASK)|(SoLazyElement::LIGHT_MODEL_MASK));
    
#ifdef WIN32
  Sleep (10000); // WINxx sleep takes milli-seconds, not seconds
#else
  sleep(5);
#endif
   
  //Rerender the floor using OpenGL again:
  glClearColor(0.8f, 0.8f, 0.8f, 1.0f);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
  glPushMatrix();
  glTranslatef(0.0f, -3.0f, 0.0f);
  glColor3f(0.0f, 0.7f, 0.0f);
  glLineWidth(2.0f);
  glDisable(GL_LIGHTING);
  drawFloor();
  glEnable(GL_LIGHTING);
  glPopMatrix();
   
  //Redraw the rest of the scene: 
  myRenderAction.apply(root);

#ifdef WIN32
  SwapBuffers(GetDC(window));
  Sleep(20000); // WINxx sleep takes milli-seconds, not seconds
#else
  glXSwapBuffers(display, window);
  sleep(10);
#endif

  root->unref();

  return 0;
}
