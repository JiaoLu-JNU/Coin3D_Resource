/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*----------------------------------------------------------------
 *  This is an example from the Inventor Mentor.
 *  chapter 15, example 1.
 *
 *  Uses an SoTranslate1Dragger to control the bottomRadius field 
 *  of an SoCone.  The 'translation' field of the dragger is the 
 *  input to an SoDecomposeVec3f engine. The engine extracts the
 *  x component from the translation. This extracted value is
 *  connected to the bottomRadius field of the cone.
 *----------------------------------------------------------------*/
#include "CoinDef.h"
#include <Inventor/engines/SoCompose.h>
#include <Inventor/nodes/SoCone.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoTransform.h>

#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>

#include <Inventor/draggers/SoTranslate1Dragger.h>

#ifdef WIN32

#endif

#define myAbs(x) ((x) < 0 ? -(x) : (x))

int
main(int, char **argv)
{
  HWND myWindow = SoWin::init(argv[0]);
  if (myWindow == NULL)
    exit(1);
  
  SoSeparator *root = new SoSeparator;
  root->ref();
  
  // Create myDragger with an initial translation of (1, 0, 0)
  SoTranslate1Dragger *myDragger = new SoTranslate1Dragger;
  root->addChild(myDragger);
  myDragger->translation.setValue(1, 0, 0);
  
  // Place an SoCone above myDragger
  SoTransform *myTransform = new SoTransform;
  SoCone *myCone = new SoCone;
  root->addChild(myTransform);
  root->addChild(myCone);
  myTransform->translation.setValue(0, 3, 0);
  
  // SoDecomposeVec3f engine extracts myDragger's x-component
  // The result is connected to myCone's bottomRadius.
  SoDecomposeVec3f *myEngine = new SoDecomposeVec3f;
  myEngine->vector.connectFrom(&myDragger->translation);
  myCone->bottomRadius.connectFrom(&(myEngine->x));
  
  // Display them in a viewer
  SoWinExaminerViewer *myViewer = new SoWinExaminerViewer(myWindow);
  myViewer->setSceneGraph(root);
  myViewer->setTitle("Dragger Edits Cone Radius");
  myViewer->viewAll();
  myViewer->show();
  
  SoWin::show(myWindow);
  SoWin::mainLoop();

  return 0;
}
