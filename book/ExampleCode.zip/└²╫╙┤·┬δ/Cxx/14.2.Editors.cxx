/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*----------------------------------------------------------------
 *  This is an example from the Inventor Mentor
 *  chapter 14, example 2.
 *
 *  Use nodekits to create a scene with a desk into an 
 *  SoWrapperKit.  Then, add a material editor for the desk and 
 *  a light editor on the light.
 *  
 *  The scene is organized using an SoSceneKit, which contains
 *  lists for grouping lights (lightList), cameras (cameraList), 
 *  and objects (childList) in a scene.
 *  
 *  Once the scene is created, a material editor is attached to 
 *  the wrapperKit's 'material' part, and a directional light editor
 *  is attached to the light's 'directionalLight' part.
 *----------------------------------------------------------------*/
#include "CoinDef.h"
#include <Inventor/SoDB.h>
#include <Inventor/SoInput.h>
#include <Inventor/Win/SoWin.h>
//#include <Inventor/Win/SoWinDirectionalLightEditor.h>
#include <Inventor/Win/SoWinMaterialEditor.h>
#include <Inventor/Win/SoWinRenderArea.h>
#include <Inventor/nodekits/SoCameraKit.h>
#include <Inventor/nodekits/SoLightKit.h>
#include <Inventor/nodekits/SoSceneKit.h>
#include <Inventor/nodekits/SoWrapperKit.h>
#include <Inventor/nodes/SoMaterial.h>
#include <Inventor/nodes/SoPerspectiveCamera.h>
#include <Inventor/nodes/SoSeparator.h>

#ifdef WIN32

#endif

int
main(int, char **argv)
{
  // Initialize Inventor and Win
  HWND myWindow = SoWin::init(argv[0]);
  if (myWindow == NULL)
    exit(1);
  // SCENE!
  SoSceneKit *myScene = new SoSceneKit;
  myScene->ref();
  
  // LIGHTS! Add an SoLightKit to the "lightList." The 
  // SoLightKit creates an SoDirectionalLight by default.
  myScene->setPart("lightList[0]", new SoLightKit);
  
  // CAMERA!! Add an SoCameraKit to the "cameraList." The 
  // SoCameraKit creates an SoPerspectiveCamera by default.
  myScene->setPart("cameraList[0]", new SoCameraKit);
  myScene->setCameraNumber(0);
  
  // Read an object from file. 
  SoInput myInput;
  if (!myInput.openFile("../data/desk.iv")) 
    exit(1);
  SoSeparator *fileContents = SoDB::readAll(&myInput);
  if (fileContents == NULL)
    exit(1);
  
  // OBJECT!! Create an SoWrapperKit and set its contents to
  // be what you read from file.
  SoWrapperKit *myDesk = new SoWrapperKit();
  myDesk->setPart("contents", fileContents);
  myScene->setPart("childList[0]", myDesk);
  
  // Give the desk a good starting color
  myDesk->set("material { diffuseColor .8 .3 .1 }");
  
  // MATERIAL EDITOR!!  Attach it to myDesk's material node.
  // Use the SO_GET_PART macro to get this part from myDesk.
  SoWinMaterialEditor *mtlEditor = new SoWinMaterialEditor();
  SoMaterial *mtl = SO_GET_PART(myDesk,"material",SoMaterial);
  mtlEditor->setTitle("Material of Desk");
  mtlEditor->show();
  mtlEditor->attach(mtl);
  
  //// DIRECTIONAL LIGHT EDITOR!! Attach it to the 
  //// SoDirectionalLight node within the SoLightKit we made.
  //SoXtDirectionalLightEditor *ltEditor = 
  //  new SoXtDirectionalLightEditor();
  //SoPath *ltPath = 
  //  myScene->createPathToPart("lightList[0].light", TRUE);
  //ltEditor->setTitle("Lighting of Desk");
  //ltEditor->show();
  //ltEditor->attach(ltPath);
  
  SoWinRenderArea *myRenderArea = new SoWinRenderArea(myWindow);
  // Set up Camera with ViewAll...
  // -- use the SO_GET_PART macro to get the camera node.
  // -- viewall is a method on the 'camera' part of 
  //    the cameraKit, not on the cameraKit itself.  So the part
  //    we ask for is not 'cameraList[0]' (which is of type 
  //    SoPerspectiveCameraKit), but 
  //    'cameraList[0].camera' (which is of type 
  //    SoPerspectiveCamera).
  SoPerspectiveCamera *myCamera = 
    SO_GET_PART(myScene, "cameraList[0].camera", SoPerspectiveCamera);
  SbViewportRegion myRegion(myRenderArea->getSize());
  myCamera->viewAll(myScene, myRegion);
  
  myRenderArea->setSceneGraph(myScene);
  myRenderArea->setTitle("Main Window: Desk In A Scene Kit");
  myRenderArea->show();
  
  SoWin::show(myWindow);
  SoWin::mainLoop();

  return 0;
}

