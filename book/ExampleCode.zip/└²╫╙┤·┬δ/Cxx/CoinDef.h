#define COIN_DLL	//#define COIN_NOT_DLL //static link
#define SOWIN_DLL	//#define SOWIN_NOT_DLL //static link
#ifdef _DEBUG
	#define COIN_LIB	"coin2d.lib"
	#define SOWIN_LIB	"sowin1d.lib"
#else 
	#define COIN_LIB	"coin2.lib"
	#define SOWIN_LIB	"sowin1.lib"
#endif
#pragma comment(lib,COIN_LIB)
#pragma comment(lib,SOWIN_LIB)

