/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*-----------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 11, example 1.
 *
 *  Example of reading from a file.
 *  Read a file given a filename and return a separator
 *  containing all of the file.  Return NULL if there is 
 *  an error reading the file.
 *----------------------------------------------------------*/

#include "CoinDef.h"
#include <Inventor/SoDB.h>
#include <Inventor/SoInput.h>
#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>
#include <Inventor/nodes/SoSeparator.h>

#ifdef WIN32

#  include "print.h"
#endif

/////////////////////////////////////////////////////////////
// CODE FOR The Inventor Mentor STARTS HERE

SoSeparator *
readFile(const char *filename)
{
  // Open the input file
  SoInput mySceneInput;
  if (!mySceneInput.openFile(filename)) {
    fprintf(stderr, "Cannot open file %s\n", filename);
    return NULL;
  }
  
  // Read the whole file into the database
  SoSeparator *myGraph = SoDB::readAll(&mySceneInput);
  if (myGraph == NULL) {
    fprintf(stderr, "Problem reading file\n");
    return NULL;
  } 
  
  mySceneInput.closeFile();
  return myGraph;
}

// CODE FOR The Inventor Mentor ENDS HERE 
/////////////////////////////////////////////////////////////

int
main(int, char **argv)
{
  // Initialize Inventor and Win
  HWND myWindow = SoWin::init(argv[0]);
  
  // Read the file
  SoSeparator *scene = readFile("../data/models/household/plant.iv");
  
  // Create a viewer
  SoWinExaminerViewer *myViewer = new SoWinExaminerViewer(myWindow);
  
  // attach and show viewer
  myViewer->setSceneGraph(scene);
  myViewer->setTitle("File Reader");
  myViewer->show();
  
  // Loop forever
  SoWin::show(myWindow);
  SoWin::mainLoop();

  return 0;
}

