/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*------------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 16, example 3.
 *
 *  This example builds a render area in a window supplied by
 *  the application and a Material Editor in its own window.
 *  It attaches the editor to the material of an object.
 *-----------------------------------------------------------*/

#include "CoinDef.h"
#include <Inventor/Win/SoWinMaterialEditor.h>

#include <Inventor/SoDB.h>         
#include <Inventor/Win/SoWin.h>         
#include <Inventor/Win/SoWinRenderArea.h>  
#include <Inventor/nodes/SoDirectionalLight.h>
#include <Inventor/nodes/SoMaterial.h>
#include <Inventor/nodes/SoPerspectiveCamera.h>
#include <Inventor/nodes/SoSeparator.h>

#ifdef WIN32

#endif

int
main(int, char **argv)
{
  // Initialize Inventor and Win
  HWND myWindow = SoWin::init(argv[0]);
   
  // Build the render area in the applications main window
  SoWinRenderArea *myRenderArea = new SoWinRenderArea(myWindow);
  myRenderArea->setSize(SbVec2s(200, 200));
   
  // Build the material editor in its own window
  SoWinMaterialEditor *myEditor = 
    new SoWinMaterialEditor(NULL, "Material Editor", FALSE);
   
  // Create a scene graph
  SoSeparator *root = new SoSeparator;
  SoPerspectiveCamera *myCamera = new SoPerspectiveCamera;
  SoMaterial *myMaterial = new SoMaterial;
   
  root->ref();
  myCamera->position.setValue(0.212482f, -0.881014f, 2.5f);
  myCamera->heightAngle = (float)(M_PI/4.0f);
  root->addChild(myCamera);
  root->addChild(new SoDirectionalLight);
  root->addChild(myMaterial);

  // Read the geometry from a file and add to the scene
  SoInput myInput;
  if (!myInput.openFile("../data/dogDish.iv"))
    exit (1);
  SoSeparator *geomObject = SoDB::readAll(&myInput);
  if (geomObject == NULL)
    exit (1);
  root->addChild(geomObject);
   
  // Set the scene graph 
  myRenderArea->setSceneGraph(root);
   
  // Attach material editor to the material
  myEditor->attach(myMaterial);
   
  // Show the application window and the material editor
  myRenderArea->setTitle("Attach Editor");
  myRenderArea->show();
  SoWin::show(myWindow);
  myEditor->show();

  // Loop forever
  SoWin::mainLoop();

  return 0;
}
