/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*--------------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 13, example 8.
 *
 *  Rotor node example.  
 *  Read in the tower and vanes of a windmill from a file.
 *  Use a rotor node to rotate the vanes.
 *------------------------------------------------------------*/

#include "CoinDef.h"
#include <Inventor/SoDB.h>
#include <Inventor/SoInput.h>
#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoRotor.h>

#ifdef WIN32

#  include "print.h"
#endif

SoSeparator *
readFile(const char *filename)
{
  // Open the input file
  SoInput mySceneInput;
  if (!mySceneInput.openFile(filename)) {
    fprintf(stderr, "Cannot open file %s\n", filename);
    return NULL;
  }
  
  // Read the whole file into the database
  SoSeparator *myGraph = SoDB::readAll(&mySceneInput);
  if (myGraph == NULL) {
    fprintf(stderr, "Problem reading file\n");
    return NULL;
  } 
  
  mySceneInput.closeFile();
  return myGraph;
}

int
main(int, char **argv)
{
  // Initialize Inventor and Win
  HWND myWindow = SoWin::init(argv[0]);
  
  SoSeparator *root = new SoSeparator;
  root->ref();
  
  // Read in the data for the windmill tower
  SoSeparator *windmillTower = 
    readFile("../data/windmillTower.iv");
  root->addChild(windmillTower);
  
  // Add a rotor node to spin the vanes
  SoRotor *myRotor = new SoRotor;
  myRotor->rotation.setValue(SbVec3f(0.0f, 0.0f, 1.0f), 
    (float)(M_PI/32.0f)); // z axis
  myRotor->speed = 0.1f;
  root->addChild(myRotor);
  
  // Read in the data for the windmill vanes
  SoSeparator *windmillVanes = 
    readFile("../data/windmillVanes.iv");
  root->addChild(windmillVanes);
  
  // Create a viewer
  SoWinExaminerViewer *myViewer = 
    new SoWinExaminerViewer(myWindow);
  
  // attach and show viewer
  myViewer->setSceneGraph(root);
  myViewer->setTitle("Windmill");
  myViewer->show();
  
  // Loop forever
  SoWin::show(myWindow);
  SoWin::mainLoop();

  return 0;
}

