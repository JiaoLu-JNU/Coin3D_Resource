/**************************************************************************
 * 		 Copyright (C) 1991-94, Silicon Graphics, Inc.		  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 **************************************************************************/

/*--------------------------------------------------------------
 *  This is an example from the Inventor Mentor,
 *  chapter 12, example 2.
 *
 *  Using getTriggerNode/getTriggerField methods of the data
 *  sensor.
 *------------------------------------------------------------*/
#include "CoinDef.h"
#include <Inventor/SoDB.h>
#include <Inventor/nodes/SoCube.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoSphere.h>
#include <Inventor/sensors/SoNodeSensor.h>

#ifdef WIN32

#  include "print.h"
#endif

// Sensor callback function:
static void
rootChangedCB(void *, SoSensor *s)
{
  // We know the sensor is really a data sensor:
  SoDataSensor *mySensor = (SoDataSensor *)s;

  SoNode *changedNode = mySensor->getTriggerNode();
  SoField *changedField = mySensor->getTriggerField();

  printf("The node named '%s' changed\n",
         changedNode->getName().getString());

  if (changedField != NULL) {
    SbName fieldName;
    changedNode->getFieldName(changedField, fieldName);
    printf(" (field %s)\n", fieldName.getString());
  }
  else {
    printf(" (no fields changed)\n");
  }
}

int
main(int, char **)
{
  SoDB::init();

  SoSeparator *root = new SoSeparator;
  root->ref();
  root->setName("Root");

  SoCube *myCube = new SoCube;
  root->addChild(myCube);
  myCube->setName("MyCube");

  SoSphere *mySphere = new SoSphere;
  root->addChild(mySphere);
  mySphere->setName("MySphere");

  SoNodeSensor *mySensor = new SoNodeSensor;

  mySensor->setPriority(0);
  mySensor->setFunction(rootChangedCB);
  mySensor->attach(root);

  // Now, make a few changes to the scene graph; the sensor's
  // callback function will be called immediately after each
  // change.
  myCube->width = 1.0;
  myCube->height = 2.0;
  mySphere->radius = 3.0;
  root->removeChild(mySphere);

  return 1;
}
